﻿namespace Tasks.DataLayer.Interfaces
{
    public interface ISoftDeletable
    {
    }
}
