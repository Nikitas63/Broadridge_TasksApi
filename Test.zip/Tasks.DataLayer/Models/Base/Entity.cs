﻿namespace Tasks.DataLayer.Models.Base
{
    public abstract class Entity
    {
    }
}
