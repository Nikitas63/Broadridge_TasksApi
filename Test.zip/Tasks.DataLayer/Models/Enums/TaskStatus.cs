﻿namespace Tasks.DataLayer.Models.Enums
{
    public enum TaskStatus
    {
        Active = 1,

        Completed = 2
    }
}
